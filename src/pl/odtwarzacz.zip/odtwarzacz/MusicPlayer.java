package pl.odtwarzacz;

abstract public class MusicPlayer implements Player{

    void addPlayer(CDPlayer cdPlayer){
        System.out.println("+++++++++");
    }

}
