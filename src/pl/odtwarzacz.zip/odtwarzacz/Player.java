package pl.odtwarzacz;

public interface Player {

    public void play();
    public void pause();
    public void stop();
    public void next();
    public void prev();

}
