package pl.odtwarzacz;

public class MP3Player extends MusicPlayer {

    Song song1 = new Song("A1", "T1", "ALB1");
    Song song2 = new Song("A2", "T2", "ALB2");

    @Override
    public void play() {
        System.out.println("MP3: Gra muzyka");

    }

    @Override
    public void pause() {
        System.out.println("MP3: Pauza w odtwarzaniu muzyki");

    }

    @Override
    public void stop() {
        System.out.println("MP3: Stop - muzyka nie gra");

    }

    @Override
    public void next() {
        System.out.println("MP3: Nastepny utwor");

    }

    @Override
    public void prev() {
        System.out.println("MP3: Poprzedni utwor");

    }
}
