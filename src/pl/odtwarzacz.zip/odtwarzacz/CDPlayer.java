package pl.odtwarzacz;

public class CDPlayer extends MusicPlayer {

    Song song1 = new Song("A1", "T1", "ALB1");
    Song song2 = new Song("A2", "T2", "ALB2");


    @Override
    public void play() {
        System.out.print("CD: Gra muzyka...");
         }

    @Override
    public void pause() {
        System.out.println("CD: Pauza w odtwarzaniu muzyki");

    }

    @Override
    public void stop() {
        System.out.println("CD: Stop - muzyka nie gra");

    }

    @Override
    public void next() {
        System.out.println("CD: Nastepny utwor");

    }

    @Override
    public void prev() {
        System.out.println("CD: Poprzedni utwor");

    }
}
