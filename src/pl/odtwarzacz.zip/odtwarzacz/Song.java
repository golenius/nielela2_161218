package pl.odtwarzacz;

public class Song {
    String artist;
    String title;
    String album;

    public Song(String artist, String title, String album) {
        this.artist = artist;
        this.title = title;
        this.album = album;
    }
}
