package pl.odtwarzacz;

public class Test {
    public static void main(String[] args) {

        CDPlayer cdPlayer = new CDPlayer();
        MP3Player mp3Player = new MP3Player();
        //cdPlayer.play();

        mp3Player.play();
        //cdPlayer.play();
        //cdPlayer.next();
        MusicPlayer musicPlayer = new MusicPlayer();
    }
}
